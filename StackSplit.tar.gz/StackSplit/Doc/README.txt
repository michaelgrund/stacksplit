For full functionality of StackSplit the following (original) SplitLab functions are modified 
within the installation process:

splitlab.m               adjustments for implementation of StackSplit
geterrorbars.m           fixed taper and ndf calculation (Walsh et al., 2013)
geterrorbarsRC.m         fixed taper and ndf calculation (Walsh et al., 2013)
preSplit.m               adjustments to save new outputs temporary
splitdiagnosticplot.m    adjustments to save new outputs temporary
saveresult.m             adjustments to save new outputs finally
